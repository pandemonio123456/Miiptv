package com.iptv.mio

import java.net.HttpURLConnection
import java.net.URL

data class Canal(val nombre: String, val grupo: String, val url: String)

object M3u {
    private val atributo = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun descargar(direccion: String): String {
        val con = URL(direccion).openConnection() as HttpURLConnection
        con.connectTimeout = 15000
        con.readTimeout = 30000
        con.instanceFollowRedirects = true
        try {
            if (con.responseCode !in 200..299) error("El servidor respondio " + con.responseCode)
            return con.inputStream.bufferedReader().use { it.readText() }
        } finally {
            con.disconnect()
        }
    }

    fun parsear(texto: String): List<Canal> {
        val salida = mutableListOf<Canal>()
        var nombre = ""
        var grupo = "Sin grupo"
        var pendiente = false
        for (cruda in texto.lineSequence()) {
            val linea = cruda.trim()
            if (linea.startsWith("#EXTINF")) {
                val attrs = atributo.findAll(linea).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                nombre = linea.substringAfterLast(",").trim().ifEmpty { attrs["tvg-name"] ?: "" }
                grupo = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "Sin grupo"
                pendiente = true
            } else if (linea.isNotEmpty() && !linea.startsWith("#") && pendiente) {
                salida.add(Canal(nombre.ifEmpty { linea }, grupo, linea))
                pendiente = false
            }
        }
        return salida
    }
}
