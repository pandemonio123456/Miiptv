package com.iptv.mio

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("mio", MODE_PRIVATE)

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(80, 60, 80, 60)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val titulo = TextView(this).apply {
            text = "Direccion de tu lista (M3U)"
            textSize = 24f
            setTextColor(Color.WHITE)
        }
        val ayuda = TextView(this).apply {
            text = "Ejemplo: http://100.x.x.x:9191/output/m3u\nUsa la misma direccion de lista que pones en TiviMate."
            textSize = 16f
            setTextColor(Color.LTGRAY)
        }
        val campo = EditText(this).apply {
            setText(prefs.getString("url", ""))
            hint = "http://..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(true)
        }
        val boton = Button(this).apply {
            text = "Guardar"
            setOnClickListener {
                prefs.edit().putString("url", campo.text.toString().trim()).apply()
                finish()
            }
        }
        val ancho = ViewGroup.LayoutParams.MATCH_PARENT
        val alto = ViewGroup.LayoutParams.WRAP_CONTENT
        raiz.addView(titulo, LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(ayuda, LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(campo, LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(boton, LinearLayout.LayoutParams(alto, alto))
        setContentView(raiz)
    }
}
