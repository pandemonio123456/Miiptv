package com.iptv.mio

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("mio", MODE_PRIVATE)

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(80, 60, 80, 60)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        fun texto(t: String, tam: Float, color: Int) = TextView(this).apply {
            text = t; textSize = tam; setTextColor(color)
        }
        fun campo(pista: String, valor: String, secreto: Boolean) = EditText(this).apply {
            setText(valor)
            hint = pista
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(true)
            if (secreto) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val servidor = campo("En casa (IP local), ej: http://192.168.1.50:9191", prefs.getString("url", "") ?: "", false)
        val servidor2 = campo("Fuera de casa (Tailscale), ej: http://100.x.x.x:9191", prefs.getString("url2", "") ?: "", false)
        val usuario = campo("Usuario (el mismo que en TiviMate)", prefs.getString("usuario", "") ?: "", false)
        val clave = campo("Contrasena", prefs.getString("clave", "") ?: "", true)
        val boton = Button(this).apply {
            text = "Guardar"
            setOnClickListener {
                prefs.edit()
                    .putString("url", servidor.text.toString().trim())
                    .putString("url2", servidor2.text.toString().trim())
                    .putString("usuario", usuario.text.toString().trim())
                    .putString("clave", clave.text.toString())
                    .apply()
                finish()
            }
        }

        val ancho = ViewGroup.LayoutParams.MATCH_PARENT
        val alto = ViewGroup.LayoutParams.WRAP_CONTENT
        raiz.addView(texto("Conexion al servidor", 24f, Color.WHITE), LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(texto("Igual que en TiviMate (Xtream). Rellena las dos direcciones: prueba primero la de casa y, si no responde, usa Tailscale (la VPN Tailscale de la TV debe estar conectada).\nPuedes dejar una vacia. Si dejas usuario vacio, el servidor se usa como lista M3U completa.", 15f, Color.LTGRAY), LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(servidor, LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(servidor2, LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(usuario, LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(clave, LinearLayout.LayoutParams(ancho, alto))
        raiz.addView(boton, LinearLayout.LayoutParams(alto, alto))
        setContentView(raiz)
    }
}
