package com.iptv.mio

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var reproductor: ExoPlayer? = null
    private lateinit var vista: PlayerView
    private lateinit var urls: Array<String>
    private lateinit var nombres: Array<String>
    private var indice = 0
    private val manejador = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        urls = intent.getStringArrayExtra("urls") ?: arrayOf()
        nombres = intent.getStringArrayExtra("nombres") ?: arrayOf()
        indice = intent.getIntExtra("indice", 0)
        vista = PlayerView(this)
        setContentView(vista)
    }

    override fun onStart() {
        super.onStart()
        val p = ExoPlayer.Builder(this).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // Reintenta el mismo canal a los 3 segundos
                manejador.postDelayed({ reproducir() }, 3000)
            }
        })
        vista.player = p
        reproductor = p
        reproducir()
    }

    override fun onStop() {
        super.onStop()
        manejador.removeCallbacksAndMessages(null)
        vista.player = null
        reproductor?.release()
        reproductor = null
    }

    private fun reproducir() {
        val p = reproductor ?: return
        if (urls.isEmpty()) return
        p.setMediaItem(MediaItem.fromUri(urls[indice]))
        p.prepare()
        p.playWhenReady = true
        Toast.makeText(this, nombres.getOrElse(indice) { "" }, Toast.LENGTH_SHORT).show()
    }

    private fun cambiar(paso: Int) {
        if (urls.isEmpty()) return
        manejador.removeCallbacksAndMessages(null)
        indice = (indice + paso + urls.size) % urls.size
        reproducir()
    }

    override fun dispatchKeyEvent(evento: KeyEvent): Boolean {
        if (evento.action == KeyEvent.ACTION_DOWN) {
            when (evento.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> { cambiar(1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { cambiar(-1); return true }
                KeyEvent.KEYCODE_DPAD_UP -> if (!vista.isControllerFullyVisible) { cambiar(1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> if (!vista.isControllerFullyVisible) { cambiar(-1); return true }
            }
        }
        return super.dispatchKeyEvent(evento)
    }
}
