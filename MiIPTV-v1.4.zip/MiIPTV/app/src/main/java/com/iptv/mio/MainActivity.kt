package com.iptv.mio

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var titulo: TextView
    private lateinit var lista: RecyclerView
    private var canales: List<Canal>? = null
    private var grupoActual: String? = null   // null = viendo grupos
    private var cargando = false
    private var ultimoContenido: String? = null
    private var version = ""
    private val manejador = Handler(Looper.getMainLooper())

    private val vigilante = object : Runnable {
        override fun run() {
            val url = urlGuardada()
            if (url.isNotEmpty() && canales != null && !cargando) cargar(url, true)
            manejador.postDelayed(this, SEGUNDOS_AUTO * 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) { "" }

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 40)
        }
        val barra = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 24)
        }
        titulo = TextView(this).apply {
            textSize = 24f
            setTextColor(Color.WHITE)
        }
        val botonRecargar = Button(this).apply {
            text = "Recargar"
            setOnClickListener { if (!cargando) recargar() }
        }
        barra.addView(titulo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        barra.addView(botonRecargar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        lista = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        raiz.addView(barra, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        raiz.addView(lista, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(raiz)
    }

    /** Direcciones a probar por orden: primero casa (IP local), luego Tailscale. */
    private fun direcciones(): List<String> {
        val prefs = getSharedPreferences("mio", MODE_PRIVATE)
        val usuario = prefs.getString("usuario", "") ?: ""
        val clave = prefs.getString("clave", "") ?: ""
        return listOf(prefs.getString("url", "") ?: "", prefs.getString("url2", "") ?: "")
            .map { M3u.direccionLista(it, usuario, clave) }
            .filter { it.isNotEmpty() }
    }

    private fun urlGuardada(): String = direcciones().firstOrNull() ?: ""

    override fun onResume() {
        super.onResume()
        val url = urlGuardada()
        if (url.isEmpty()) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        if (canales == null && !cargando) cargar(url, false)
        // Comprueba cada minuto si la lista ha cambiado
        manejador.removeCallbacks(vigilante)
        manejador.postDelayed(vigilante, SEGUNDOS_AUTO * 1000L)
        if (canales != null && !cargando) cargar(url, true)
    }

    override fun onPause() {
        super.onPause()
        manejador.removeCallbacks(vigilante)
    }

    private fun cargar(url: String, silencioso: Boolean) {
        cargando = true
        if (!silencioso) {
            titulo.text = "Mi IPTV v$version - cargando lista..."
            lista.adapter = Adaptador(emptyList()) {}
        }
        thread {
            try {
                val candidatas = direcciones()
                var texto: String? = null
                var fallo: Exception? = null
                for (d in candidatas) {
                    try {
                        // Con dos servidores, prueba rapido el primero y salta al siguiente
                        texto = M3u.descargar(d, if (candidatas.size > 1) 4000 else 15000)
                        break
                    } catch (e: Exception) {
                        fallo = e
                    }
                }
                if (texto == null) throw (fallo ?: IllegalStateException("Sin servidor configurado"))
                val lectura = M3u.parsear(texto)
                runOnUiThread {
                    cargando = false
                    val cambio = texto != ultimoContenido
                    ultimoContenido = texto
                    if (silencioso && !cambio) return@runOnUiThread   // nada nuevo
                    canales = lectura
                    val g = grupoActual
                    when {
                        !silencioso || g == null -> mostrarGrupos()
                        g == "Todos los canales" -> mostrarCanales(g, lectura)
                        else -> mostrarCanales(g, lectura.filter { it.grupo == g })
                    }
                    if (silencioso) {
                        Toast.makeText(this, "Lista actualizada: " + lectura.size + " canales", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    cargando = false
                    if (!silencioso) {
                        titulo.text = "Mi IPTV v$version - no se pudo cargar: " + (e.message ?: e.javaClass.simpleName)
                        mostrarMenuError()
                    }
                    // Si falla una recarga silenciosa, se mantiene la lista anterior
                }
            }
        }
    }

    private fun recargar() {
        canales = null
        grupoActual = null
        ultimoContenido = null
        val url = urlGuardada()
        if (url.isNotEmpty()) cargar(url, false)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Boton Menu del mando: recarga la lista
        if (keyCode == KeyEvent.KEYCODE_MENU && !cargando) {
            recargar()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun mostrarMenuError() {
        lista.adapter = Adaptador(listOf("Reintentar", "Ajustes")) { i ->
            if (i == 0) recargar() else startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun mostrarGrupos() {
        grupoActual = null
        val todos = canales ?: return
        val grupos = todos.map { it.grupo }.distinct()
        titulo.text = "Mi IPTV v$version - " + todos.size + " canales"
        val filas = mutableListOf("Todos los canales")
        filas.addAll(grupos)
        filas.add("Ajustes")
        lista.adapter = Adaptador(filas) { i ->
            when {
                i == 0 -> mostrarCanales("Todos los canales", todos)
                i == filas.size - 1 -> startActivity(Intent(this, SettingsActivity::class.java))
                else -> mostrarCanales(grupos[i - 1], todos.filter { it.grupo == grupos[i - 1] })
            }
        }
        lista.requestFocus()
    }

    private fun mostrarCanales(nombreGrupo: String, delGrupo: List<Canal>) {
        grupoActual = nombreGrupo
        titulo.text = nombreGrupo
        lista.adapter = Adaptador(delGrupo.map { it.nombre }) { i ->
            val intent = Intent(this, PlayerActivity::class.java)
            intent.putExtra("urls", delGrupo.map { it.url }.toTypedArray())
            intent.putExtra("nombres", delGrupo.map { it.nombre }.toTypedArray())
            intent.putExtra("indice", i)
            startActivity(intent)
        }
        lista.requestFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (grupoActual != null && canales != null) mostrarGrupos() else super.onBackPressed()
    }

    companion object {
        // Cada cuantos segundos se comprueba si la lista ha cambiado (mientras la app esta abierta)
        const val SEGUNDOS_AUTO = 60
    }

    private class Adaptador(
        private val filas: List<String>,
        private val alPulsar: (Int) -> Unit
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(padre: ViewGroup, tipo: Int): RecyclerView.ViewHolder {
            val vista = TextView(padre.context).apply {
                textSize = 20f
                setTextColor(Color.WHITE)
                setPadding(32, 24, 32, 24)
                isFocusable = true
                isClickable = true
                setBackgroundResource(R.drawable.item_bg)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).also { it.setMargins(0, 0, 0, 8) }
            }
            return object : RecyclerView.ViewHolder(vista) {}
        }

        override fun onBindViewHolder(titular: RecyclerView.ViewHolder, posicion: Int) {
            val vista = titular.itemView as TextView
            vista.text = filas[posicion]
            vista.setOnClickListener { alPulsar(titular.bindingAdapterPosition) }
        }

        override fun getItemCount() = filas.size
    }
}
