package com.iptv.mio

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private val botonesPerfil = mutableListOf<Button>()
    private val botonesEditar = mutableListOf<Button>()
    private lateinit var campoOcultar: EditText
    private var formatoElegido = "ajuste"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La pantalla no se apaga mientras la app esta abierta
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(60), dp(40), dp(60), dp(40))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun add(v: View) {
            col.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun texto(t: String, tam: Float = 16f, color: Int = Color.LTGRAY): TextView =
            TextView(this).apply {
                text = t
                textSize = tam
                setTextColor(color)
                setPadding(0, dp(12), 0, dp(4))
            }

        fun boton(t: String, accion: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { accion() }
                Estilo.aplicarBoton(this)
            }

        add(texto("Ajustes", 26f, Color.WHITE))
        add(texto("Segundos hasta ocultar los controles del vídeo"))
        campoOcultar = EditText(this).apply {
            setText(Repo.segundosOcultar(this@SettingsActivity).toString())
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            Estilo.aplicarCampo(this)
        }
        add(campoOcultar)

        add(texto("Formato de pantalla completa"))
        val opcionesFormato = listOf("ajuste" to "Automático (ajustar, sin cortar)", "llenar" to "Llenar pantalla (puede cortar)")
        val desplegableFormato = Spinner(this).apply {
            adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_item, opcionesFormato.map { it.second })
                .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            setPopupBackgroundDrawable(ColorDrawable(0xFF101820.toInt()))
            background = Estilo.pastilla(this@SettingsActivity, 0x1FFFFFFF, 14, 0x33FFFFFF, 1)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            Estilo.animarFoco(this, 1.02f)
            setSelection(opcionesFormato.indexOfFirst { it.first == Repo.formatoVideo(this@SettingsActivity) }.coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(padre: AdapterView<*>?, vista: View?, posicion: Int, id: Long) {
                    formatoElegido = opcionesFormato[posicion].first
                }

                override fun onNothingSelected(padre: AdapterView<*>?) {}
            }
        }
        formatoElegido = Repo.formatoVideo(this)
        add(desplegableFormato)

        add(boton("Guardar ajustes") {
            val valor = campoOcultar.text.toString().toIntOrNull() ?: 2
            Repo.prefs(this).edit()
                .putInt("ocultar", valor.coerceIn(1, 10))
                .putString("formato", formatoElegido)
                .apply()
            aviso("Ajustes guardados")
        })

        add(texto("Perfiles (hasta ${Repo.MAX_PERFILES}). Pulsa el nombre para usarlo.", 18f, Color.WHITE))
        for (i in 0 until Repo.MAX_PERFILES) {
            val nombre = boton("") { elegirPerfil(i) }
            val editar = boton("Editar") { abrirPerfil(i) }
            val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fila.addView(nombre, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(12) })
            fila.addView(editar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            add(fila)
            botonesPerfil.add(nombre)
            botonesEditar.add(editar)
        }

        add(texto("MINIPTV · versión " + versionApp(this), 14f))
        setContentView(Estilo.envolver(this, scroll))
    }

    override fun onResume() {
        super.onResume()
        refrescarPerfiles()
    }

    private fun refrescarPerfiles() {
        val activo = Repo.perfilActual(this)
        for (i in botonesPerfil.indices) {
            if (Repo.existe(this, i)) {
                val nombre = Repo.campo(this, i, "nombre").ifBlank { "sin nombre" }
                val marca = if (i == activo) "  ·  en uso" else ""
                botonesPerfil[i].text = "Perfil ${i + 1}: $nombre$marca"
                botonesEditar[i].visibility = View.VISIBLE
            } else {
                botonesPerfil[i].text = "Perfil ${i + 1}: + añadir"
                botonesEditar[i].visibility = View.GONE
            }
        }
    }

    /** Pulsar el nombre de un perfil lo pone en uso; un hueco libre abre la alta. */
    private fun elegirPerfil(i: Int) {
        if (!Repo.existe(this, i)) {
            abrirPerfil(i)
            return
        }
        Repo.activar(this, i)
        aviso("Perfil en uso: " + Repo.campo(this, i, "nombre").ifBlank { "sin nombre" })
        refrescarPerfiles()
    }

    private fun abrirPerfil(i: Int) {
        startActivity(android.content.Intent(this, ProfileActivity::class.java).putExtra("indice", i))
    }
}
