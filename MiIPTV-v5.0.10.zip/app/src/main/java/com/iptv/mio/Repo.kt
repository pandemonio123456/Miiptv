package com.iptv.mio

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import java.util.concurrent.Executors

/** Perfiles guardados (hasta 3), ajustes y la lista de canales en memoria. */
object Repo {
    const val MAX_PERFILES = 3
    private val hilo = Executors.newSingleThreadExecutor()
    private val principal = Handler(Looper.getMainLooper())
    private var ultimoTexto: String? = null
    private var seguras: SharedPreferences? = null
    private val campos = listOf("nombre", "url", "usuario", "clave", "recarga", "imagen", "ultimo", "tipo", "ok")

    var canales: List<Canal> = emptyList()
        private set

    /** Ajustes y perfiles cifrados (contraseñas incluidas). Borra la version sin cifrar de antes. */
    fun prefs(ctx: Context): SharedPreferences {
        seguras?.let { return it }
        val app = ctx.applicationContext
        app.getSharedPreferences("mio", Context.MODE_PRIVATE).edit().clear().apply()
        val alias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        val p = EncryptedSharedPreferences.create(
            "mio_seguro",
            alias,
            app,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        seguras = p
        return p
    }

    fun activo(ctx: Context): Int = prefs(ctx).getInt("activo", 0)

    fun campo(ctx: Context, i: Int, nombre: String): String =
        prefs(ctx).getString("p${i}_$nombre", "").orEmpty()

    fun existe(ctx: Context, i: Int): Boolean =
        i in 0 until MAX_PERFILES && campo(ctx, i, "url").isNotBlank()

    fun tipoDe(ctx: Context, i: Int): String = campo(ctx, i, "tipo").ifBlank { "xtream" }

    fun perfilActual(ctx: Context): Int {
        val a = activo(ctx)
        if (existe(ctx, a)) return a
        return (0 until MAX_PERFILES).firstOrNull { existe(ctx, it) } ?: -1
    }

    /** Primer perfil guardado de ese tipo ("xtream" o "m3u"), o -1. */
    fun primerPerfil(ctx: Context, tipo: String): Int =
        (0 until MAX_PERFILES).firstOrNull { existe(ctx, it) && tipoDe(ctx, it) == tipo } ?: -1

    /** Primer hueco libre, o -1 si estan los 3 perfiles. */
    fun primeraLibre(ctx: Context): Int =
        (0 until MAX_PERFILES).firstOrNull { !existe(ctx, it) } ?: -1

    fun configurado(ctx: Context): Boolean = perfilActual(ctx) >= 0

    fun nombreLista(ctx: Context): String {
        val i = perfilActual(ctx)
        return if (i < 0) "MINIPTV" else campo(ctx, i, "nombre").ifBlank { "MINIPTV" }
    }

    fun segundosOcultar(ctx: Context): Int = prefs(ctx).getInt("ocultar", 2).coerceIn(1, 10)

    /** Formato del vídeo en pantalla completa: "ajuste" (entero, sin cortar) por defecto, o "llenar" (recorta). */
    fun formatoVideo(ctx: Context): String = prefs(ctx).getString("formato", "ajuste") ?: "ajuste"

    fun recargaDe(ctx: Context, i: Int): Int = prefs(ctx).getInt("p${i}_recarga", -1)

    /** Minutos entre comprobaciones: 0 = no comprobar, -1 = cada vez que entras. */
    fun recarga(ctx: Context): Int {
        val i = perfilActual(ctx)
        return if (i < 0) 0 else recargaDe(ctx, i)
    }

    fun milisRecarga(ctx: Context): Long {
        val m = recarga(ctx)
        return if (m > 0) m * 60_000L else -1L
    }

    fun recargarAlEntrar(ctx: Context): Boolean = recarga(ctx) == -1

    fun imagenActiva(ctx: Context): String {
        val i = perfilActual(ctx)
        return if (i < 0) "" else campo(ctx, i, "imagen")
    }

    fun ultimo(ctx: Context): String {
        val i = perfilActual(ctx)
        return if (i < 0) "" else campo(ctx, i, "ultimo")
    }

    fun guardarUltimo(ctx: Context, nombre: String) {
        val i = perfilActual(ctx)
        if (i >= 0) prefs(ctx).edit().putString("p${i}_ultimo", nombre).apply()
    }

    /** Clasifica un grupo de la lista en: series, peliculas o tv (el resto). */
    fun seccionDe(grupo: String): String {
        val g = grupo.lowercase()
        return when {
            Regex("serie|temporada|season").containsMatchIn(g) -> "series"
            Regex("pel[ií]cula|movie|film|\\bvod\\b|cine").containsMatchIn(g) -> "peliculas"
            else -> "tv"
        }
    }

    fun canalesDe(seccion: String): List<Canal> = canales.filter { seccionDe(it.grupo) == seccion }

    fun delGrupo(nombre: String, seccion: String): List<Canal> =
        if (nombre == "Todos los canales") canalesDe(seccion) else canalesDe(seccion).filter { it.grupo == nombre }

    fun invalidar() {
        canales = emptyList()
        ultimoTexto = null
    }

    /** La cuenta activa se ha cargado bien alguna vez: se entra directo a las carpetas. */
    fun verificadoActivo(ctx: Context): Boolean {
        val i = perfilActual(ctx)
        return i >= 0 && prefs(ctx).getBoolean("p${i}_ok", false)
    }

    fun activar(ctx: Context, i: Int) {
        prefs(ctx).edit().putInt("activo", i).apply()
        invalidar()
    }

    fun guardarPerfil(
        ctx: Context, i: Int, nombre: String, url: String,
        usuario: String, clave: String, recarga: Int, imagen: String, tipo: String
    ) {
        prefs(ctx).edit()
            .putString("p${i}_tipo", tipo)
            .putString("p${i}_nombre", nombre)
            .putString("p${i}_url", url)
            .putString("p${i}_usuario", usuario)
            .putString("p${i}_clave", clave)
            .putInt("p${i}_recarga", recarga)
            .putString("p${i}_imagen", imagen)
            .putBoolean("p${i}_ok", false)
            .apply()
        invalidar()
    }

    fun borrarPerfil(ctx: Context, i: Int) {
        val ed = prefs(ctx).edit()
        for (c in campos) ed.remove("p${i}_$c")
        ed.apply()
        if (activo(ctx) == i) {
            val otro = (0 until MAX_PERFILES).firstOrNull { it != i && existe(ctx, it) } ?: 0
            prefs(ctx).edit().putInt("activo", otro).apply()
        }
        invalidar()
    }

    private fun direccion(ctx: Context): String {
        val i = perfilActual(ctx)
        if (i < 0) return ""
        if (tipoDe(ctx, i) == "m3u") return campo(ctx, i, "url")
        return M3u.direccionLista(campo(ctx, i, "url"), campo(ctx, i, "usuario"), campo(ctx, i, "clave"))
    }

    /** Descarga la lista del perfil activo. alTerminar(ok, mensaje, hayCambios) se llama en el hilo principal. */
    fun cargar(ctx: Context, alTerminar: (Boolean, String, Boolean) -> Unit) {
        val dir = direccion(ctx)
        if (dir.isEmpty()) {
            alTerminar(false, "Falta la dirección de la lista", false)
            return
        }
        hilo.execute {
            var texto: String? = null
            var fallo = ""
            try {
                texto = M3u.descargar(dir)
            } catch (e: Exception) {
                fallo = e.message ?: e.javaClass.simpleName
            }
            val resultado = texto
            principal.post {
                if (resultado == null) {
                    alTerminar(false, fallo, false)
                } else {
                    val i = perfilActual(ctx)
                    if (i >= 0) prefs(ctx).edit().putBoolean("p${i}_ok", true).apply()
                    val cambio = resultado != ultimoTexto
                    if (cambio) {
                        ultimoTexto = resultado
                        canales = M3u.parsear(resultado)
                    }
                    alTerminar(true, "", cambio)
                }
            }
        }
    }
}
