# Oculta el nombre de los archivos fuente en los errores
-renamesourcefileattribute SourceFile
-keepattributes !SourceFile,!LineNumberTable
