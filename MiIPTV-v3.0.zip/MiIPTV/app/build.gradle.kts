plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iptv.mio"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.iptv.mio"
        minSdk = 23
        targetSdk = 34
        versionCode = 7
        versionName = "3.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { buildConfig = true }
    flavorDimensions += "version"
    productFlavors {
        create("completa") {
            dimension = "version"
            buildConfigField("String", "SERVIDOR_FIJO", "\"\"")
            buildConfigField("boolean", "SOLO_USUARIO", "false")
            resValue("string", "app_name", "MINIPTV")
        }
        create("prueba1") {
            dimension = "version"
            applicationIdSuffix = ".prueba1"
            versionNameSuffix = "-prueba1"
            buildConfigField("String", "SERVIDOR_FIJO", "\"http://100.93.253.126:9191\"")
            buildConfigField("boolean", "SOLO_USUARIO", "true")
            resValue("string", "app_name", "Prueba 1")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("androidx.security:security-crypto:1.0.0")
}
