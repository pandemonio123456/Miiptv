package com.iptv.mio

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private val botonesPerfil = mutableListOf<Button>()
    private lateinit var campoOcultar: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(60), dp(40), dp(60), dp(40))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun add(v: View) {
            col.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun texto(t: String, tam: Float = 16f, color: Int = Color.LTGRAY): TextView =
            TextView(this).apply {
                text = t
                textSize = tam
                setTextColor(color)
                setPadding(0, dp(12), 0, dp(4))
            }

        fun boton(t: String, accion: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { accion() }
                Estilo.aplicarBoton(this)
            }

        add(texto("Ajustes", 26f, Color.WHITE))
        add(texto("Segundos hasta ocultar los controles del vídeo"))
        campoOcultar = EditText(this).apply {
            setText(Repo.segundosOcultar(this@SettingsActivity).toString())
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            Estilo.aplicarCampo(this)
        }
        add(campoOcultar)
        add(boton("Guardar ajustes") {
            val valor = campoOcultar.text.toString().toIntOrNull() ?: 2
            Repo.prefs(this).edit().putInt("ocultar", valor.coerceIn(1, 10)).apply()
            aviso("Ajustes guardados")
        })

        add(texto("Perfiles (hasta ${Repo.MAX_PERFILES})", 18f, Color.WHITE))
        for (i in 0 until Repo.MAX_PERFILES) {
            val b = boton("") { abrirPerfil(i) }
            botonesPerfil.add(b)
            add(b)
        }

        add(texto("MINIPTV · versión " + versionApp(this), 14f))
        setContentView(Estilo.envolver(this, scroll))
    }

    override fun onResume() {
        super.onResume()
        refrescarPerfiles()
    }

    private fun refrescarPerfiles() {
        val activo = Repo.perfilActual(this)
        for (i in botonesPerfil.indices) {
            botonesPerfil[i].text = if (Repo.existe(this, i)) {
                val marca = if (i == activo) "  ·  activo" else ""
                "Perfil ${i + 1}: " + Repo.campo(this, i, "nombre").ifBlank { "sin nombre" } + marca
            } else {
                "Perfil ${i + 1}: + añadir"
            }
        }
    }

    private fun abrirPerfil(i: Int) {
        startActivity(Intent(this, ProfileActivity::class.java).putExtra("indice", i))
    }
}
