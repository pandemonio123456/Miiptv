package com.iptv.mio

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private var indice = 0
    private var nuevo = true
    private var primera = false
    private var recarga = 10
    private var imagen = ""
    private var tipo = "xtream"
    private var confirmarBorrado = false
    private val soloUsuario = BuildConfig.SOLO_USUARIO
    private val esM3u: Boolean
        get() = tipo == "m3u"

    private lateinit var campoNombre: EditText
    private lateinit var campoUrl: EditText
    private lateinit var campoUsuario: EditText
    private lateinit var campoClave: EditText
    private lateinit var etiquetaRecarga: Button
    private lateinit var etiquetaImagen: TextView
    private lateinit var botonBorrar: Button

    private val opcionesRecarga = listOf(
        0 to "No comprobar",
        5 to "Cada 5 minutos",
        10 to "Cada 10 minutos",
        30 to "Cada 30 minutos",
        -1 to "Cada vez que entro"
    )

    private val elegirImagen = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // Si no se puede guardar el permiso, la imagen podria dejar de verse al reiniciar
            }
            imagen = uri.toString()
            actualizarImagen()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        primera = intent.getBooleanExtra("primera", false) || !Repo.configurado(this)
        val pedido = intent.getIntExtra("indice", -1)
        indice = if (primera || pedido < 0) primeraLibre() else pedido
        nuevo = !Repo.existe(this, indice)
        tipo = if (nuevo) (intent.getStringExtra("tipo") ?: "xtream") else Repo.tipoDe(this, indice)
        recarga = if (nuevo) 10 else Repo.recargaDe(this, indice)
        imagen = if (nuevo) "" else Repo.campo(this, indice, "imagen")

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(60), dp(40), dp(60), dp(40))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun add(v: View) {
            col.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun texto(t: String, tam: Float = 16f, color: Int = Color.LTGRAY): TextView =
            TextView(this).apply {
                text = t
                textSize = tam
                setTextColor(color)
                setPadding(0, dp(12), 0, dp(4))
            }

        fun campo(pista: String, valor: String, secreto: Boolean): EditText =
            EditText(this).apply {
                hint = pista
                setText(valor)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                inputType = if (secreto) {
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else {
                    InputType.TYPE_CLASS_TEXT
                }
                setSingleLine(true)
                Estilo.aplicarCampo(this)
            }

        fun boton(t: String, accion: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { accion() }
                Estilo.aplicarBoton(this)
            }

        val titulo = when {
            primera -> "Primera configuración"
            esM3u -> "Lista M3U"
            nuevo -> "Nuevo perfil"
            else -> "Perfil ${indice + 1}"
        }
        add(texto(titulo, 26f, Color.WHITE))

        // Si el perfil ya existe, la direccion y el usuario salen ocultos
        campoUrl = campo(
            if (esM3u) "http://servidor/lista.m3u" else "http://192.168.1.50:9191",
            Repo.campo(this, indice, "url"),
            !nuevo
        )
        campoUsuario = campo("Usuario", Repo.campo(this, indice, "usuario"), !nuevo)
        campoClave = campo("Contraseña", Repo.campo(this, indice, "clave"), true)
        campoNombre = campo("MINIPTV", Repo.campo(this, indice, "nombre"), false)

        if (!soloUsuario) {
            add(texto(if (esM3u) "Enlace de la lista M3U" else "Dirección del servidor"))
            add(campoUrl)
        }
        if (!esM3u) {
            add(texto("Usuario"))
            add(campoUsuario)
            add(texto("Contraseña"))
            add(campoClave)

            val verClave = CheckBox(this).apply {
                text = "Mostrar contraseña"
                setTextColor(Color.WHITE)
                textSize = 16f
                buttonTintList = ColorStateList.valueOf(Estilo.CYAN)
                setOnCheckedChangeListener { _, marcado ->
                    val posicion = campoClave.selectionEnd
                    campoClave.transformationMethod = if (marcado) null else PasswordTransformationMethod.getInstance()
                    campoClave.setSelection(posicion.coerceIn(0, campoClave.text.length))
                }
            }
            add(verClave)
        }

        if (!primera) {
            add(texto("Nombre de la lista"))
            add(campoNombre)

            etiquetaRecarga = boton(textoRecarga()) {
                val pos = opcionesRecarga.indexOfFirst { it.first == recarga }
                val siguiente = opcionesRecarga[(if (pos < 0) 0 else pos + 1) % opcionesRecarga.size]
                recarga = siguiente.first
                etiquetaRecarga.text = textoRecarga()
            }
            add(texto("Comprobar cambios en la lista"))
            add(etiquetaRecarga)

            etiquetaImagen = TextView(this).apply {
                textSize = 16f
                setTextColor(Color.LTGRAY)
                setPadding(0, dp(12), 0, dp(4))
            }
            add(texto("Imagen de fondo de este perfil"))
            add(etiquetaImagen)
            add(boton("Elegir imagen") { elegirImagen.launch(arrayOf("image/*")) })
            add(boton("Quitar imagen") {
                imagen = ""
                actualizarImagen()
            })
        }

        add(boton(if (primera) "Entrar" else "Guardar") { guardar(primera) })
        if (!primera) {
            add(boton("Guardar y usar este perfil") { guardar(true) })
        }
        if (!nuevo && !primera) {
            botonBorrar = boton("Borrar perfil") { pulsarBorrar() }
            add(botonBorrar)
        }

        actualizarImagen()
        setContentView(Estilo.envolver(this, scroll))
    }

    private fun primeraLibre(): Int =
        (0 until Repo.MAX_PERFILES).firstOrNull { !Repo.existe(this, it) } ?: 0

    private fun textoRecarga(): String {
        val etiqueta = opcionesRecarga.firstOrNull { it.first == recarga }?.second ?: "Cada 10 minutos"
        return "Comprobar cambios: $etiqueta"
    }

    private fun actualizarImagen() {
        if (!::etiquetaImagen.isInitialized) return
        etiquetaImagen.text = if (imagen.isBlank()) "Ninguna (degradado oscuro)" else "Imagen elegida"
    }

    private fun guardar(usar: Boolean) {
        val servidor = if (soloUsuario) BuildConfig.SERVIDOR_FIJO else campoUrl.text.toString().trim()
        if (servidor.isEmpty()) {
            aviso(if (esM3u) "Escribe el enlace de la lista" else "Escribe la dirección del servidor")
            return
        }
        Repo.guardarPerfil(
            this,
            indice,
            campoNombre.text.toString().trim(),
            servidor,
            if (esM3u) "" else campoUsuario.text.toString().trim(),
            if (esM3u) "" else campoClave.text.toString(),
            recarga,
            imagen,
            tipo
        )
        if (usar) Repo.activar(this, indice)
        finish()
    }

    private fun pulsarBorrar() {
        if (!confirmarBorrado) {
            confirmarBorrado = true
            botonBorrar.text = "Pulsa otra vez para borrar"
            return
        }
        Repo.borrarPerfil(this, indice)
        aviso("Perfil borrado")
        finish()
    }
}
