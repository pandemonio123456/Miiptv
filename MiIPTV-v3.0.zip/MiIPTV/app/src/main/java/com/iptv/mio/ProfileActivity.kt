package com.iptv.mio

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    private var indice = 0
    private var nuevo = true
    private var primera = false
    private var recarga = 10
    private var imagen = ""
    private var confirmarBorrado = false

    private lateinit var campoNombre: EditText
    private lateinit var campoUrl: EditText
    private lateinit var campoUsuario: EditText
    private lateinit var campoClave: EditText
    private lateinit var etiquetaRecarga: Button
    private lateinit var etiquetaImagen: TextView
    private lateinit var botonBorrar: Button

    private val opcionesRecarga = listOf(
        0 to "No comprobar",
        5 to "Cada 5 minutos",
        10 to "Cada 10 minutos",
        30 to "Cada 30 minutos",
        -1 to "Cada vez que entro"
    )

    private val elegirImagen = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // Si no se puede guardar el permiso, la imagen podria dejar de verse al reiniciar
            }
            imagen = uri.toString()
            actualizarImagen()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        primera = intent.getBooleanExtra("primera", false) || !Repo.configurado(this)
        indice = if (primera) primeraLibre() else intent.getIntExtra("indice", 0)
        nuevo = !Repo.existe(this, indice)
        recarga = if (nuevo) 10 else Repo.recargaDe(this, indice)
        imagen = if (nuevo) "" else Repo.campo(this, indice, "imagen")

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(60), dp(40), dp(60), dp(40))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun add(v: View) {
            col.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun texto(t: String, tam: Float = 16f, color: Int = Color.LTGRAY): TextView =
            TextView(this).apply {
                text = t
                textSize = tam
                setTextColor(color)
                setPadding(0, dp(12), 0, dp(4))
            }

        fun campo(pista: String, valor: String, secreto: Boolean): EditText =
            EditText(this).apply {
                hint = pista
                setText(valor)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                inputType = if (secreto) {
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else {
                    InputType.TYPE_CLASS_TEXT
                }
                setSingleLine(true)
                Estilo.aplicarCampo(this)
            }

        fun boton(t: String, accion: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { accion() }
                Estilo.aplicarBoton(this)
            }

        val titulo = when {
            primera -> "Primera configuración"
            nuevo -> "Nuevo perfil"
            else -> "Perfil ${indice + 1}"
        }
        add(texto(titulo, 26f, Color.WHITE))

        // Si el perfil ya existe, la direccion y el usuario salen ocultos (solo se ven al escribirlos)
        campoUrl = campo("http://192.168.1.50:9191", Repo.campo(this, indice, "url"), !nuevo)
        campoUsuario = campo("Usuario", Repo.campo(this, indice, "usuario"), !nuevo)
        campoClave = campo("Contraseña", Repo.campo(this, indice, "clave"), true)
        campoNombre = campo("MINIPTV", Repo.campo(this, indice, "nombre"), false)

        add(texto("Dirección del servidor"))
        add(campoUrl)
        add(texto("Usuario"))
        add(campoUsuario)
        add(texto("Contraseña"))
        add(campoClave)

        if (!primera) {
            add(texto("Nombre de la lista"))
            add(campoNombre)

            etiquetaRecarga = boton(textoRecarga()) {
                val pos = opcionesRecarga.indexOfFirst { it.first == recarga }
                val siguiente = opcionesRecarga[(if (pos < 0) 0 else pos + 1) % opcionesRecarga.size]
                recarga = siguiente.first
                etiquetaRecarga.text = textoRecarga()
            }
            add(texto("Comprobar cambios en la lista"))
            add(etiquetaRecarga)

            etiquetaImagen = TextView(this).apply {
                textSize = 16f
                setTextColor(Color.LTGRAY)
                setPadding(0, dp(12), 0, dp(4))
            }
            add(texto("Imagen de fondo de este perfil"))
            add(etiquetaImagen)
            add(boton("Elegir imagen") { elegirImagen.launch(arrayOf("image/*")) })
            add(boton("Quitar imagen") {
                imagen = ""
                actualizarImagen()
            })
        }

        add(boton(if (primera) "Entrar" else "Guardar") { guardar(primera) })
        if (!primera) {
            add(boton("Guardar y usar este perfil") { guardar(true) })
        }
        if (!nuevo && !primera) {
            botonBorrar = boton("Borrar perfil") { pulsarBorrar() }
            add(botonBorrar)
        }

        actualizarImagen()
        setContentView(Estilo.envolver(this, scroll))
    }

    private fun primeraLibre(): Int =
        (0 until Repo.MAX_PERFILES).firstOrNull { !Repo.existe(this, it) } ?: 0

    private fun textoRecarga(): String {
        val etiqueta = opcionesRecarga.firstOrNull { it.first == recarga }?.second ?: "Cada 10 minutos"
        return "Comprobar cambios: $etiqueta"
    }

    private fun actualizarImagen() {
        if (!::etiquetaImagen.isInitialized) return
        etiquetaImagen.text = if (imagen.isBlank()) "Ninguna (degradado oscuro)" else "Imagen elegida"
    }

    private fun guardar(usar: Boolean) {
        val servidor = campoUrl.text.toString().trim()
        if (servidor.isEmpty()) {
            aviso("Escribe la dirección del servidor")
            return
        }
        Repo.guardarPerfil(
            this,
            indice,
            campoNombre.text.toString().trim(),
            servidor,
            campoUsuario.text.toString().trim(),
            campoClave.text.toString(),
            recarga,
            imagen
        )
        if (usar) Repo.activar(this, indice)
        finish()
    }

    private fun pulsarBorrar() {
        if (!confirmarBorrado) {
            confirmarBorrado = true
            botonBorrar.text = "Pulsa otra vez para borrar"
            return
        }
        Repo.borrarPerfil(this, indice)
        aviso("Perfil borrado")
        finish()
    }
}
