package com.iptv.mio

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/** Perfiles guardados (hasta 5), ajustes y la lista de canales en memoria. */
object Repo {
    const val MAX_PERFILES = 5
    private val hilo = Executors.newSingleThreadExecutor()
    private val principal = Handler(Looper.getMainLooper())
    private var ultimoTexto: String? = null
    private val campos = listOf("nombre", "url", "usuario", "clave", "recarga", "imagen", "ultimo")

    var canales: List<Canal> = emptyList()
        private set

    private var seguras: SharedPreferences? = null

    /** Ajustes y perfiles cifrados (contraseñas incluidas). Borra la version sin cifrar de antes. */
    fun prefs(ctx: Context): SharedPreferences {
        seguras?.let { return it }
        val app = ctx.applicationContext
        app.getSharedPreferences("mio", Context.MODE_PRIVATE).edit().clear().apply()
        val alias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        val p = EncryptedSharedPreferences.create(
            "mio_seguro",
            alias,
            app,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        seguras = p
        return p
    }

    fun activo(ctx: Context): Int = prefs(ctx).getInt("activo", 0)

    fun campo(ctx: Context, i: Int, nombre: String): String =
        prefs(ctx).getString("p${i}_$nombre", "").orEmpty()

    fun existe(ctx: Context, i: Int): Boolean =
        i in 0 until MAX_PERFILES && campo(ctx, i, "url").isNotBlank()

    fun perfilActual(ctx: Context): Int {
        val a = activo(ctx)
        if (existe(ctx, a)) return a
        return (0 until MAX_PERFILES).firstOrNull { existe(ctx, it) } ?: -1
    }

    fun configurado(ctx: Context): Boolean = perfilActual(ctx) >= 0

    fun nombreLista(ctx: Context): String {
        val i = perfilActual(ctx)
        return if (i < 0) "MINIPTV" else campo(ctx, i, "nombre").ifBlank { "MINIPTV" }
    }

    fun segundosOcultar(ctx: Context): Int = prefs(ctx).getInt("ocultar", 2).coerceIn(1, 10)

    fun recargaDe(ctx: Context, i: Int): Int = prefs(ctx).getInt("p${i}_recarga", 10)

    /** Minutos entre comprobaciones: 0 = no comprobar, -1 = cada vez que entras. */
    fun recarga(ctx: Context): Int {
        val i = perfilActual(ctx)
        return if (i < 0) 0 else recargaDe(ctx, i)
    }

    fun milisRecarga(ctx: Context): Long {
        val m = recarga(ctx)
        return if (m > 0) m * 60_000L else -1L
    }

    fun recargarAlEntrar(ctx: Context): Boolean = recarga(ctx) == -1

    fun imagenActiva(ctx: Context): String {
        val i = perfilActual(ctx)
        return if (i < 0) "" else campo(ctx, i, "imagen")
    }

    fun ultimo(ctx: Context): String {
        val i = perfilActual(ctx)
        return if (i < 0) "" else campo(ctx, i, "ultimo")
    }

    fun guardarUltimo(ctx: Context, nombre: String) {
        val i = perfilActual(ctx)
        if (i >= 0) prefs(ctx).edit().putString("p${i}_ultimo", nombre).apply()
    }

    fun delGrupo(nombre: String): List<Canal> =
        if (nombre == "Todos los canales") canales else canales.filter { it.grupo == nombre }

    fun invalidar() {
        canales = emptyList()
        ultimoTexto = null
    }

    fun activar(ctx: Context, i: Int) {
        prefs(ctx).edit().putInt("activo", i).apply()
        invalidar()
    }

    fun guardarPerfil(
        ctx: Context, i: Int, nombre: String, url: String,
        usuario: String, clave: String, recarga: Int, imagen: String
    ) {
        prefs(ctx).edit()
            .putString("p${i}_nombre", nombre)
            .putString("p${i}_url", url)
            .putString("p${i}_usuario", usuario)
            .putString("p${i}_clave", clave)
            .putInt("p${i}_recarga", recarga)
            .putString("p${i}_imagen", imagen)
            .apply()
        invalidar()
    }

    fun borrarPerfil(ctx: Context, i: Int) {
        val ed = prefs(ctx).edit()
        for (c in campos) ed.remove("p${i}_$c")
        ed.apply()
        if (activo(ctx) == i) {
            val otro = (0 until MAX_PERFILES).firstOrNull { it != i && existe(ctx, it) } ?: 0
            prefs(ctx).edit().putInt("activo", otro).apply()
        }
        invalidar()
    }

    private fun direccion(ctx: Context): String {
        val i = perfilActual(ctx)
        if (i < 0) return ""
        return M3u.direccionLista(campo(ctx, i, "url"), campo(ctx, i, "usuario"), campo(ctx, i, "clave"))
    }

    /** Descarga la lista del perfil activo. alTerminar(ok, mensaje, hayCambios) se llama en el hilo principal. */
    fun cargar(ctx: Context, alTerminar: (Boolean, String, Boolean) -> Unit) {
        val dir = direccion(ctx)
        if (dir.isEmpty()) {
            alTerminar(false, "Falta la dirección del servidor", false)
            return
        }
        hilo.execute {
            var texto: String? = null
            var fallo = ""
            try {
                texto = M3u.descargar(dir)
            } catch (e: Exception) {
                fallo = e.message ?: e.javaClass.simpleName
            }
            val resultado = texto
            principal.post {
                if (resultado == null) {
                    alTerminar(false, fallo, false)
                } else {
                    val cambio = resultado != ultimoTexto
                    if (cambio) {
                        ultimoTexto = resultado
                        canales = M3u.parsear(resultado)
                    }
                    alTerminar(true, "", cambio)
                }
            }
        }
    }
}
