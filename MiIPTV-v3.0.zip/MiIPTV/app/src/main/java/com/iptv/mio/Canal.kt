package com.iptv.mio

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Canal(val nombre: String, val grupo: String, val url: String)

object M3u {
    private val atributo = Regex("([\\w-]+)=\"([^\"]*)\"")

    /** Igual que TiviMate con Xtream: servidor + usuario + contrasena (get.php del servidor). */
    fun direccionLista(servidor: String, usuario: String, clave: String): String {
        var base = servidor.trim()
        if (base.isEmpty()) return ""
        if (!base.startsWith("http://") && !base.startsWith("https://")) base = "http://" + base
        if (usuario.isBlank()) return base
        base = base.trimEnd('/')
        val u = URLEncoder.encode(usuario.trim(), "UTF-8")
        val c = URLEncoder.encode(clave, "UTF-8")
        return "$base/get.php?username=$u&password=$c&type=m3u_plus&output=ts"
    }

    fun descargar(direccion: String, conexionMs: Int = 15000): String {
        val con = URL(direccion).openConnection() as HttpURLConnection
        con.connectTimeout = conexionMs
        con.readTimeout = 30000
        con.instanceFollowRedirects = true
        try {
            if (con.responseCode !in 200..299) error("El servidor respondio " + con.responseCode)
            return con.inputStream.bufferedReader().use { it.readText() }
        } finally {
            con.disconnect()
        }
    }

    fun parsear(texto: String): List<Canal> {
        val salida = mutableListOf<Canal>()
        var nombre = ""
        var grupo = "Sin grupo"
        var pendiente = false
        for (cruda in texto.lineSequence()) {
            val linea = cruda.trim()
            if (linea.startsWith("#EXTINF")) {
                val attrs = atributo.findAll(linea).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                nombre = linea.substringAfterLast(",").trim().ifEmpty { attrs["tvg-name"] ?: "" }
                grupo = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "Sin grupo"
                pendiente = true
            } else if (linea.isNotEmpty() && !linea.startsWith("#") && pendiente) {
                salida.add(Canal(nombre.ifEmpty { linea }, grupo, linea))
                pendiente = false
            }
        }
        return salida
    }
}
