package com.iptv.mio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

/** Fondo animado: manchas de color suaves que recorren toda la pantalla. */
class FondoVivo(ctx: Context, private val conBase: Boolean) : View(ctx) {
    private val pincel = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pincelBase = Paint()
    private val inicio = System.nanoTime()
    private val colores = intArrayOf(0x7A00E5FF.toInt(), 0x7A7C4DFF.toInt(), 0x7AFF4081.toInt())
    private var mancha: Array<Bitmap> = emptyArray()
    private var radio = 0f

    init {
        // Una sola textura por color, reescalada al dibujar: barata de pintar en TV
        mancha = Array(colores.size) { i -> crearMancha(colores[i]) }
    }

    private fun crearMancha(color: Int): Bitmap {
        val lado = 256
        val bmp = Bitmap.createBitmap(lado, lado, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = lado / 2f
        p.shader = RadialGradient(r, r, r, color, 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(r, r, r, p)
        return bmp
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pincelBase.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            0xFF0B1020.toInt(), 0xFF05070D.toInt(), Shader.TileMode.CLAMP
        )
        // El radio cubre toda la pantalla para que no queden bordes vacios
        radio = maxOf(w, h) * 0.75f
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (conBase) c.drawRect(0f, 0f, w, h, pincelBase)
        val t = (System.nanoTime() - inicio) / 1_000_000_000f
        val escala = radio * 2f / 256f
        for (i in mancha.indices) {
            val fase = t * (0.18f + i * 0.07f) + i * 2.1f
            val cx = w * (0.5f + 0.4f * sin(fase))
            val cy = h * (0.5f + 0.4f * cos(fase * 0.8f + i))
            c.save()
            c.translate(cx - radio, cy - radio)
            c.scale(escala, escala)
            c.drawBitmap(mancha[i], 0f, 0f, pincel)
            c.restore()
        }
        postInvalidateOnAnimation()
    }
}

/** Estilos comunes: botones, campos, tarjetas y brillo al enfocar (mando de TV). */
object Estilo {
    const val CYAN = 0xFF00E5FF.toInt()
    const val VIOLETA = 0xFF7C4DFF.toInt()

    fun pastilla(ctx: Context, relleno: Int, radio: Int, borde: Int = 0, anchoBorde: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(relleno)
            cornerRadius = ctx.dp(radio).toFloat()
            if (borde != 0) setStroke(ctx.dp(anchoBorde), borde)
        }

    fun botonEstado(ctx: Context): StateListDrawable {
        val foco = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(CYAN, VIOLETA)).apply {
            cornerRadius = ctx.dp(28).toFloat()
        }
        val normal = pastilla(ctx, 0x33FFFFFF, 28, 0x40FFFFFF, 1)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), foco)
            addState(intArrayOf(android.R.attr.state_pressed), foco)
            addState(intArrayOf(), normal)
        }
    }

    fun aplicarBoton(b: Button) {
        val ctx = b.context
        b.background = botonEstado(ctx)
        b.setTextColor(Color.WHITE)
        b.textSize = 18f
        b.isAllCaps = false
        b.minHeight = ctx.dp(64)
        b.setPadding(ctx.dp(28), ctx.dp(12), ctx.dp(28), ctx.dp(12))
        animarFoco(b, 1.06f)
    }

    fun ponerIcono(b: Button, icono: Int) {
        b.setCompoundDrawablesRelativeWithIntrinsicBounds(icono, 0, 0, 0)
        b.compoundDrawablePadding = b.context.dp(14)
    }

    fun aplicarCampo(e: EditText) {
        e.background = pastilla(e.context, 0x1FFFFFFF, 14, 0x33FFFFFF, 1)
        e.setPadding(e.context.dp(18), e.context.dp(14), e.context.dp(18), e.context.dp(14))
        e.setTextColor(Color.WHITE)
        e.textSize = 18f
    }

    fun animarFoco(v: View, escala: Float) {
        v.setOnFocusChangeListener { vista, enFoco ->
            val s = if (enFoco) escala else 1f
            vista.animate().scaleX(s).scaleY(s).setDuration(160).start()
        }
    }

    fun redondearVisor(v: View, radio: Int) {
        v.background = pastilla(v.context, 0xFF000000.toInt(), radio)
        v.clipToOutline = true
        v.outlineProvider = ViewOutlineProvider.BACKGROUND
    }

    /** Borde cian cuando el mando enfoca la mini pantalla. */
    fun marcoVisor(ctx: Context): StateListDrawable {
        val foco = GradientDrawable().apply {
            setColor(0x00000000)
            cornerRadius = ctx.dp(18).toFloat()
            setStroke(ctx.dp(4), CYAN)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), foco)
            addState(intArrayOf(), ColorDrawable(0x00000000))
        }
    }

    fun envolver(ctx: Context, contenido: View): FrameLayout {
        val raiz = FrameLayout(ctx)
        raiz.addView(FondoVivo(ctx, true), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        raiz.addView(contenido, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return raiz
    }
}
