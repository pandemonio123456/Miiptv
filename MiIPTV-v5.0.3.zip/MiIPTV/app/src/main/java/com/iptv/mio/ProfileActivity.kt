package com.iptv.mio

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.text.method.TransformationMethod
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Perfil de Xstream o de lista M3U.
 * La contraseña se escribe una vez: mientras se escribe se ve solo el ultimo caracter
 * un segundo y luego todo son asteriscos. Guardada, nunca se vuelve a mostrar:
 * para cambiarla hay que borrar el perfil y volver a meterlo.
 */
class ProfileActivity : AppCompatActivity() {

    private var indice = 0
    private var nuevo = true
    private var recarga = 10
    private var imagen = ""
    private var tipo = "xtream"
    private var confirmarBorrado = false
    private lateinit var campoNombre: EditText
    private lateinit var campoServidor: EditText
    private lateinit var campoUsuario: EditText
    private lateinit var campoClave: EditText
    private lateinit var mostrarClave: CheckBox
    private lateinit var textoGuardada: TextView
    private lateinit var etiquetaServidor: TextView
    private lateinit var bloqueXtream: LinearLayout
    private lateinit var bXtream: Button
    private lateinit var bM3u: Button
    private lateinit var etiquetaImagen: TextView
    private lateinit var botonBorrar: Button

    private val opcionesRecarga = listOf(
        0 to "No comprobar",
        5 to "Cada 5 minutos",
        10 to "Cada 10 minutos",
        30 to "Cada 30 minutos",
        -1 to "Cada vez que entro"
    )

    private val elegirImagen = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // Si no se puede guardar el permiso, la imagen podria dejar de verse al reiniciar
            }
            imagen = uri.toString()
            actualizarImagen()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La pantalla no se apaga mientras la app esta abierta
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val pedido = intent.getIntExtra("indice", -1)
        indice = if (pedido >= 0) pedido else maxOf(Repo.primeraLibre(this), 0)
        nuevo = !Repo.existe(this, indice)
        tipo = if (nuevo) (intent.getStringExtra("tipo") ?: "xtream") else Repo.tipoDe(this, indice)
        recarga = if (nuevo) -1 else Repo.recargaDe(this, indice)
        imagen = if (nuevo) "" else Repo.campo(this, indice, "imagen")

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(60), dp(40), dp(60), dp(40))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun en(padre: LinearLayout, v: View) {
            padre.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun add(v: View) = en(col, v)

        fun texto(t: String, tam: Float = 16f, color: Int = Color.LTGRAY): TextView =
            TextView(this).apply {
                text = t
                textSize = tam
                setTextColor(color)
                setPadding(0, dp(12), 0, dp(4))
            }

        fun campoTexto(pista: String, valor: String): EditText =
            EditText(this).apply {
                hint = pista
                setText(valor)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                inputType = InputType.TYPE_CLASS_TEXT
                setSingleLine(true)
                Estilo.aplicarCampo(this)
            }

        fun boton(t: String, accion: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { accion() }
                Estilo.aplicarBoton(this)
            }

        add(texto(if (nuevo) "Nuevo perfil" else "Perfil ${indice + 1}", 26f, Color.WHITE))

        // Tipo de origen: solo se elige al crear el perfil
        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bXtream = boton("Xstream") { if (nuevo) { tipo = "xtream"; aplicarTipo() } }
        bM3u = boton("Lista M3U") { if (nuevo) { tipo = "m3u"; aplicarTipo() } }
        fila.addView(bXtream, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })
        fila.addView(bM3u, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
        fila.visibility = if (nuevo) View.VISIBLE else View.GONE
        add(fila)

        etiquetaServidor = texto("")
        add(etiquetaServidor)
        campoServidor = campoTexto("", Repo.campo(this, indice, "url"))
        add(campoServidor)

        // Solo Xstream: usuario y contraseña
        bloqueXtream = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        campoUsuario = campoTexto("Usuario", Repo.campo(this, indice, "usuario"))
        en(bloqueXtream, texto("Usuario"))
        en(bloqueXtream, campoUsuario)
        en(bloqueXtream, texto("Contraseña"))

        campoClave = EditText(this).apply {
            hint = "Contraseña"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            // Tipo contraseña: el teclado sabe que es una clave. Los puntos los pone PuntosOcultos.
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            Estilo.aplicarCampo(this)
            transformationMethod = PuntosOcultos()
        }
        en(bloqueXtream, campoClave)

        mostrarClave = CheckBox(this).apply {
            text = "Mostrar contraseña"
            setTextColor(Color.WHITE)
            textSize = 16f
            buttonTintList = ColorStateList.valueOf(Estilo.CYAN)
            setOnCheckedChangeListener { _, marcado ->
                val pos = campoClave.selectionEnd
                campoClave.transformationMethod = if (marcado) null else PuntosOcultos()
                campoClave.setSelection(pos.coerceIn(0, campoClave.text.length))
            }
        }
        en(bloqueXtream, mostrarClave)

        // Perfil ya guardado: la contraseña no se lee ni se muestra
        textoGuardada = texto("•••••••• guardada. No se puede editar. Para cambiarla, borra el perfil y vuelve a meterlo.")
        en(bloqueXtream, textoGuardada)
        campoClave.visibility = if (nuevo) View.VISIBLE else View.GONE
        mostrarClave.visibility = if (nuevo) View.VISIBLE else View.GONE
        textoGuardada.visibility = if (nuevo) View.GONE else View.VISIBLE
        add(bloqueXtream)

        add(texto("Nombre de la lista"))
        campoNombre = campoTexto("MINIPTV", Repo.campo(this, indice, "nombre"))
        add(campoNombre)

        add(texto("Comprobar cambios en la lista"))
        val desplegable = Spinner(this).apply {
            adapter = ArrayAdapter(this@ProfileActivity, android.R.layout.simple_spinner_item, opcionesRecarga.map { it.second })
                .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            setPopupBackgroundDrawable(ColorDrawable(0xFF101820.toInt()))
            background = Estilo.pastilla(this@ProfileActivity, 0x1FFFFFFF, 14, 0x33FFFFFF, 1)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            Estilo.animarFoco(this, 1.02f)
            setSelection(opcionesRecarga.indexOfFirst { it.first == recarga }.coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(padre: AdapterView<*>?, vista: View?, posicion: Int, id: Long) {
                    recarga = opcionesRecarga[posicion].first
                }

                override fun onNothingSelected(padre: AdapterView<*>?) {}
            }
        }
        add(desplegable)

        etiquetaImagen = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(4))
        }
        add(texto("Imagen de fondo de este perfil"))
        add(etiquetaImagen)
        add(boton("Elegir imagen") { elegirImagen.launch(arrayOf("image/*")) })
        add(boton("Quitar imagen") {
            imagen = ""
            actualizarImagen()
        })

        add(boton(if (nuevo) "Guardar" else "Guardar cambios") { guardar(false) })
        add(boton("Guardar y usar este perfil") { guardar(true) })
        if (!nuevo) {
            botonBorrar = boton("Borrar perfil") { pulsarBorrar() }
            add(botonBorrar)
        }

        setContentView(Estilo.envolver(this, scroll))
        aplicarTipo()
        actualizarImagen()
    }

    override fun onPause() {
        super.onPause()
        // Al salir de la pantalla, la contraseña vuelve a quedar tapada
        if (::mostrarClave.isInitialized) mostrarClave.isChecked = false
    }

    private fun aplicarTipo() {
        val xtream = tipo == "xtream"
        bloqueXtream.visibility = if (xtream) View.VISIBLE else View.GONE
        etiquetaServidor.text = if (xtream) "IP del servidor" else "Enlace de la lista M3U"
        campoServidor.hint = if (xtream) "http://192.168.1.50:9191" else "http://servidor/lista.m3u"
        bXtream.text = (if (xtream) "✓  " else "") + "Xstream"
        bM3u.text = (if (!xtream) "✓  " else "") + "Lista M3U"
    }

    private fun actualizarImagen() {
        if (!::etiquetaImagen.isInitialized) return
        etiquetaImagen.text = if (imagen.isBlank()) "Ninguna (degradado oscuro)" else "Imagen elegida"
    }

    private fun guardar(usar: Boolean) {
        val servidor = campoServidor.text.toString().trim()
        val xtream = tipo == "xtream"
        if (servidor.isEmpty()) {
            aviso(if (xtream) "Escribe la IP del servidor" else "Escribe el enlace de la lista")
            return
        }
        var usuario = ""
        var clave = ""
        if (xtream) {
            usuario = campoUsuario.text.toString().trim()
            // Al editar, la contraseña guardada se conserva sin pasar por pantalla
            clave = if (nuevo) campoClave.text.toString() else Repo.campo(this, indice, "clave")
            if (usuario.isEmpty() || clave.isEmpty()) {
                aviso("Escribe el usuario y la contraseña")
                return
            }
        }
        val nombre = campoNombre.text.toString().trim().ifBlank { "MINIPTV" }
        Repo.guardarPerfil(this, indice, nombre, servidor, usuario, clave, recarga, imagen, tipo)
        if (usar) Repo.activar(this, indice)
        finish()
    }

    private fun pulsarBorrar() {
        if (!confirmarBorrado) {
            confirmarBorrado = true
            botonBorrar.text = "Pulsa otra vez para borrar"
            return
        }
        Repo.borrarPerfil(this, indice)
        aviso("Perfil borrado")
        finish()
    }
}

/** Muestra un punto por cada caracter. Siempre igual: no deja ver ninguna letra. */
class PuntosOcultos : TransformationMethod {
    override fun getTransformation(origen: CharSequence, vista: View?): CharSequence =
        "\u2022".repeat(origen.length)

    override fun onFocusChanged(vista: View?, origen: CharSequence?, enFoco: Boolean, direccion: Int, rectangulo: Rect?) {
    }
}
