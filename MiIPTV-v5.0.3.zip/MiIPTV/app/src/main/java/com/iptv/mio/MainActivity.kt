package com.iptv.mio

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var fondo: ImageView
    private lateinit var bXtream: Button
    private lateinit var bM3u: Button
    private lateinit var bVivo: Button
    private lateinit var bPeliculas: Button
    private lateinit var bSeries: Button
    private lateinit var circulo: ProgressBar
    private val manejador = Handler(Looper.getMainLooper())

    private val vigilante = object : Runnable {
        override fun run() {
            cargar(true)
            val ms = Repo.milisRecarga(this@MainActivity)
            if (ms > 0) manejador.postDelayed(this, ms)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Mantiene la pantalla encendida mientras la app esta abierta
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val raiz = FrameLayout(this)
        // Imagen de fondo entera (encaja en pantalla) sobre fondo oscuro
        fondo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF05070D.toInt())
        }
        raiz.addView(fondo, pantalla())
        raiz.addView(View(this).apply { setBackgroundColor(Color.argb(110, 0, 0, 0)) }, pantalla())
        raiz.addView(FondoVivo(this, false), pantalla())

        // Primero: Xtream y Lista M3U. Con una cuenta verificada: TV en vivo, Peliculas y Series.
        bXtream = boton("Xtream", R.drawable.ic_tv) { abrirTipo("xtream") }
        bM3u = boton("Lista M3U", R.drawable.ic_list) { abrirTipo("m3u") }
        bVivo = boton("TV en vivo", R.drawable.ic_tv) { abrirSeccion("tv") }
        bPeliculas = boton("Películas", R.drawable.ic_play) { abrirSeccion("peliculas") }
        bSeries = boton("Series", R.drawable.ic_list) { abrirSeccion("series") }

        val botones = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        for (b in listOf(bXtream, bM3u, bVivo, bPeliculas, bSeries)) botones.addView(b, botonParams())
        raiz.addView(
            botones,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL or Gravity.END).apply {
                rightMargin = dp(120)
            }
        )

        // Engranaje arriba a la derecha: siempre visible, configuracion y perfiles
        val engranaje = ImageButton(this).apply {
            setImageResource(R.drawable.ic_settings)
            background = Estilo.botonEstado(this@MainActivity)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        Estilo.animarFoco(engranaje, 1.08f)
        raiz.addView(
            engranaje,
            FrameLayout.LayoutParams(dp(72), dp(72), Gravity.TOP or Gravity.END).apply {
                topMargin = dp(28)
                rightMargin = dp(40)
            }
        )

        circulo = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(Estilo.CYAN)
            visibility = View.GONE
        }
        raiz.addView(circulo, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        setContentView(raiz)
    }

    private fun pantalla() = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    private fun boton(texto: String, icono: Int, accion: () -> Unit): Button =
        Button(this).apply {
            text = texto
            setOnClickListener { accion() }
            Estilo.aplicarBoton(this)
            Estilo.ponerIcono(this, icono)
        }

    private fun botonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(14) }

    override fun onResume() {
        super.onResume()
        fondo.setImageDrawable(fondoDrawable(this))
        actualizarPantalla(true)
        // Por defecto comprueba la lista cada vez que entras
        if (Repo.configurado(this) && (Repo.canales.isEmpty() || Repo.recargarAlEntrar(this))) {
            cargar(Repo.canales.isNotEmpty())
        }
        manejador.removeCallbacks(vigilante)
        val ms = Repo.milisRecarga(this)
        if (ms > 0 && Repo.configurado(this)) manejador.postDelayed(vigilante, ms)
    }

    override fun onPause() {
        super.onPause()
        manejador.removeCallbacks(vigilante)
    }

    /** Xtream o Lista M3U: usa el perfil de ese tipo, o crea uno si no existe. */
    private fun abrirTipo(tipo: String) {
        val i = Repo.primerPerfil(this, tipo)
        if (i >= 0) {
            Repo.activar(this, i)
            cargar(false)
        } else if (Repo.primeraLibre(this) < 0) {
            aviso("Ya tienes 3 perfiles. Borra uno en el engranaje.")
        } else {
            startActivity(Intent(this, ProfileActivity::class.java).putExtra("tipo", tipo))
        }
    }

    private fun abrirSeccion(seccion: String) {
        startActivity(Intent(this, LiveActivity::class.java).putExtra("seccion", seccion))
    }

    private fun actualizarPantalla(enfocar: Boolean) {
        val verificado = Repo.verificadoActivo(this)
        for (b in listOf(bXtream, bM3u)) b.visibility = if (verificado) View.GONE else View.VISIBLE
        for (b in listOf(bVivo, bPeliculas, bSeries)) b.visibility = if (verificado) View.VISIBLE else View.GONE
        if (enfocar) (if (verificado) bVivo else bXtream).requestFocus()
    }

    private fun cargar(silencioso: Boolean) {
        if (!silencioso) circulo.visibility = View.VISIBLE
        Repo.cargar(this) { ok, mensaje, cambio ->
            if (!isDestroyed) {
                if (!silencioso) circulo.visibility = View.GONE
                actualizarPantalla(false)
                if (!ok) {
                    if (!silencioso) aviso("No se pudo cargar: $mensaje")
                } else if (cambio && silencioso) {
                    aviso("Lista actualizada: ${Repo.canales.size} canales")
                } else if (!cambio && !silencioso) {
                    aviso("La lista no ha cambiado")
                }
            }
        }
    }
}
