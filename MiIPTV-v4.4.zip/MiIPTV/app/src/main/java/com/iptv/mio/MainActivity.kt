package com.iptv.mio

import android.animation.ObjectAnimator
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var titulo: TextView
    private lateinit var info: TextView
    private lateinit var fondo: ImageView
    private lateinit var bXtream: Button
    private lateinit var bVivo: Button
    private lateinit var circulo: ProgressBar
    private val manejador = Handler(Looper.getMainLooper())

    private val vigilante = object : Runnable {
        override fun run() {
            cargar(true)
            val ms = Repo.milisRecarga(this@MainActivity)
            if (ms > 0) manejador.postDelayed(this, ms)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Mantiene la pantalla encendida mientras la app esta abierta
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val raiz = FrameLayout(this)
        // La imagen se ve entera (encaja) sobre fondo oscuro, sin recortarla
        fondo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF05070D.toInt())
        }
        raiz.addView(fondo, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        raiz.addView(
            View(this).apply { setBackgroundColor(Color.argb(110, 0, 0, 0)) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        raiz.addView(
            FondoVivo(this, false),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val logo = ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }
        titulo = TextView(this).apply {
            textSize = 48f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.04f
            alpha = 0f
        }
        info = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFB8F2FF.toInt())
            setPadding(dp(16), dp(6), dp(16), dp(6))
            background = Estilo.pastilla(this@MainActivity, 0x2200E5FF, 20, 0x6600E5FF, 1)
        }

        val izquierda = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        izquierda.addView(logo, LinearLayout.LayoutParams(dp(120), dp(120)).apply { bottomMargin = dp(18) })
        izquierda.addView(titulo, anchoCompleto())
        izquierda.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        bXtream = boton("Xtream", R.drawable.ic_tv) { abrirTipo("xtream") }
        bVivo = boton("TV en vivo", R.drawable.ic_play) {
            startActivity(Intent(this, LiveActivity::class.java))
        }
        bVivo.visibility = View.GONE

        val derecha = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        derecha.addView(bXtream, botonParams())
        derecha.addView(boton("Lista M3U", R.drawable.ic_list) { abrirTipo("m3u") }, botonParams())
        derecha.addView(boton("Recargar lista", R.drawable.ic_refresh) { cargar(false) }, botonParams())
        derecha.addView(bVivo, botonParams())

        val columna = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(80), dp(40), dp(80), dp(40))
        }
        columna.addView(izquierda, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        columna.addView(derecha, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        raiz.addView(columna, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER_VERTICAL))

        // Engranaje arriba a la derecha: configuracion
        val engranaje = ImageButton(this).apply {
            setImageResource(R.drawable.ic_settings)
            background = Estilo.botonEstado(this@MainActivity)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        Estilo.animarFoco(engranaje, 1.08f)
        raiz.addView(
            engranaje,
            FrameLayout.LayoutParams(dp(72), dp(72), Gravity.TOP or Gravity.END).apply {
                topMargin = dp(28)
                rightMargin = dp(40)
            }
        )

        circulo = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(Estilo.CYAN)
            visibility = View.GONE
        }
        raiz.addView(circulo, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        setContentView(raiz)

        // Movimiento: el logo flota y el titulo aparece suave
        ObjectAnimator.ofFloat(logo, "translationY", 0f, -dp(10).toFloat(), 0f).apply {
            duration = 2400
            repeatCount = ObjectAnimator.INFINITE
            start()
        }
        titulo.animate().alpha(1f).setDuration(900).start()
    }

    private fun boton(texto: String, icono: Int, accion: () -> Unit): Button =
        Button(this).apply {
            text = texto
            setOnClickListener { accion() }
            Estilo.aplicarBoton(this)
            Estilo.ponerIcono(this, icono)
        }

    private fun botonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(14) }

    private fun anchoCompleto() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    override fun onResume() {
        super.onResume()
        fondo.setImageDrawable(fondoDrawable(this))
        actualizarTextos()
        if (Repo.configurado(this) && (Repo.canales.isEmpty() || Repo.recargarAlEntrar(this))) {
            cargar(Repo.canales.isNotEmpty())
        }
        if (bVivo.visibility == View.VISIBLE) bVivo.requestFocus() else bXtream.requestFocus()
        manejador.removeCallbacks(vigilante)
        val ms = Repo.milisRecarga(this)
        if (ms > 0 && Repo.configurado(this)) manejador.postDelayed(vigilante, ms)
    }

    override fun onPause() {
        super.onPause()
        manejador.removeCallbacks(vigilante)
    }

    /** Xtream o Lista M3U: usa el perfil de ese tipo, o crea uno si no existe. */
    private fun abrirTipo(tipo: String) {
        val i = Repo.primerPerfil(this, tipo)
        if (i >= 0) {
            Repo.activar(this, i)
            cargar(false)
        } else if (Repo.primeraLibre(this) < 0) {
            aviso("Ya tienes 3 perfiles. Borra uno en el engranaje.")
        } else {
            startActivity(Intent(this, ProfileActivity::class.java).putExtra("tipo", tipo))
        }
    }

    private fun actualizarTextos() {
        titulo.text = Repo.nombreLista(this)
        info.text = if (Repo.canales.isEmpty()) {
            if (Repo.configurado(this)) "Lista sin cargar" else "Pulsa Xtream o Lista M3U para empezar"
        } else {
            Repo.canales.size.toString() + " canales  ·  v" + versionApp(this)
        }
        bVivo.visibility = if (Repo.canales.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun cargar(silencioso: Boolean) {
        if (!silencioso) circulo.visibility = View.VISIBLE
        Repo.cargar(this) { ok, mensaje, cambio ->
            if (!isDestroyed) {
                if (!silencioso) circulo.visibility = View.GONE
                actualizarTextos()
                if (!ok) {
                    if (!silencioso) aviso("No se pudo cargar: $mensaje")
                } else if (cambio && silencioso) {
                    aviso("Lista actualizada: ${Repo.canales.size} canales")
                } else if (!cambio && !silencioso) {
                    aviso("La lista no ha cambiado")
                }
            }
        }
    }
}
