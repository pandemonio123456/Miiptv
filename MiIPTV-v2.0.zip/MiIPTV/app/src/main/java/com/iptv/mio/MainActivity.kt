package com.iptv.mio

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var titulo: TextView
    private lateinit var info: TextView
    private lateinit var fondo: ImageView
    private lateinit var bVivo: Button
    private val manejador = Handler(Looper.getMainLooper())

    private val vigilante = object : Runnable {
        override fun run() {
            cargar(true)
            val ms = Repo.milisRecarga(this@MainActivity)
            if (ms > 0) manejador.postDelayed(this, ms)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val raiz = FrameLayout(this)
        fondo = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        raiz.addView(fondo, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        raiz.addView(
            View(this).apply { setBackgroundColor(Color.argb(170, 0, 0, 0)) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        titulo = TextView(this).apply {
            textSize = 42f
            setTextColor(Color.WHITE)
        }
        info = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(6), 0, dp(36))
        }
        bVivo = boton("TV en vivo") {
            startActivity(Intent(this, LiveActivity::class.java))
        }

        val columna = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(80), dp(40), dp(80), dp(40))
        }
        columna.addView(titulo, anchoCompleto())
        columna.addView(info, anchoCompleto())
        columna.addView(bVivo, botonParams())
        columna.addView(boton("Recargar lista") { cargar(false) }, botonParams())
        columna.addView(boton("Ajustes") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }, botonParams())

        raiz.addView(
            columna,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER_VERTICAL)
        )
        setContentView(raiz)
    }

    private fun boton(texto: String, accion: () -> Unit): Button =
        Button(this).apply {
            text = texto
            setOnClickListener { accion() }
        }

    private fun botonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(14) }

    private fun anchoCompleto() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    override fun onResume() {
        super.onResume()
        if (!Repo.configurado(this)) {
            startActivity(Intent(this, ProfileActivity::class.java).putExtra("primera", true))
            return
        }
        fondo.setImageDrawable(fondoDrawable(this))
        actualizarTextos()
        if (Repo.canales.isEmpty() || Repo.recargarAlEntrar(this)) {
            cargar(Repo.canales.isNotEmpty())
        }
        bVivo.requestFocus()
        manejador.removeCallbacks(vigilante)
        val ms = Repo.milisRecarga(this)
        if (ms > 0) manejador.postDelayed(vigilante, ms)
    }

    override fun onPause() {
        super.onPause()
        manejador.removeCallbacks(vigilante)
    }

    private fun actualizarTextos() {
        titulo.text = Repo.nombreLista(this)
        info.text = Repo.canales.size.toString() + " canales  ·  v" + versionApp(this)
    }

    private fun cargar(silencioso: Boolean) {
        Repo.cargar(this) { ok, mensaje, cambio ->
            if (!isDestroyed) {
                actualizarTextos()
                if (!ok) {
                    if (!silencioso) aviso("No se pudo cargar: $mensaje")
                } else if (cambio && silencioso) {
                    aviso("Lista actualizada: ${Repo.canales.size} canales")
                } else if (!cambio && !silencioso) {
                    aviso("La lista no ha cambiado")
                }
            }
        }
    }
}
