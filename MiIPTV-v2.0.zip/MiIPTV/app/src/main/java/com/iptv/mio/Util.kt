package com.iptv.mio

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

fun Context.dp(valor: Int): Int = (valor * resources.displayMetrics.density).toInt()

fun Context.aviso(texto: String) {
    Toast.makeText(this, texto, Toast.LENGTH_SHORT).show()
}

/** Fondo: usa assets/fondo.jpg si existe (tu foto); si no, un degradado. */
fun fondoDrawable(ctx: Context): Drawable {
    try {
        val bmp = ctx.assets.open("fondo.jpg").use { BitmapFactory.decodeStream(it) }
        if (bmp != null) return BitmapDrawable(ctx.resources, bmp)
    } catch (e: Exception) {
        // No hay foto: se usa el degradado
    }
    return GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(0xFF1B2735.toInt(), 0xFF090A0F.toInt())
    )
}

fun versionApp(ctx: Context): String = try {
    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
} catch (e: Exception) {
    ""
}

class Adaptador(
    private val filas: List<String>,
    private val alPulsar: (Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(padre: ViewGroup, tipo: Int): RecyclerView.ViewHolder {
        val vista = TextView(padre.context).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(32, 22, 32, 22)
            isFocusable = true
            isClickable = true
            setBackgroundResource(R.drawable.item_bg)
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(0, 0, 0, 8) }
        }
        return object : RecyclerView.ViewHolder(vista) {}
    }

    override fun onBindViewHolder(titular: RecyclerView.ViewHolder, posicion: Int) {
        val vista = titular.itemView as TextView
        vista.text = filas[posicion]
        vista.setOnClickListener { alPulsar(titular.bindingAdapterPosition) }
    }

    override fun getItemCount() = filas.size
}
