package com.iptv.mio

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/** Ajustes guardados y la lista de canales en memoria. */
object Repo {
    private val hilo = Executors.newSingleThreadExecutor()
    private val principal = Handler(Looper.getMainLooper())
    private var ultimoTexto: String? = null

    var canales: List<Canal> = emptyList()
        private set

    fun prefs(ctx: Context) = ctx.getSharedPreferences("mio", Context.MODE_PRIVATE)
    fun configurado(ctx: Context) = prefs(ctx).getString("url", "").orEmpty().isNotBlank()
    fun nombreLista(ctx: Context) = prefs(ctx).getString("nombre", "").orEmpty().ifBlank { "MINIPTV" }
    fun segundosOcultar(ctx: Context) = prefs(ctx).getInt("ocultar", 2).coerceIn(1, 10)
    fun intervalo(ctx: Context) = prefs(ctx).getInt("intervalo", 60).coerceIn(15, 3600)
    fun autoRecarga(ctx: Context) = prefs(ctx).getBoolean("auto", true)
    fun ultimo(ctx: Context): String = prefs(ctx).getString("ultimo", "").orEmpty()

    fun guardarUltimo(ctx: Context, nombre: String) {
        prefs(ctx).edit().putString("ultimo", nombre).apply()
    }

    fun delGrupo(nombre: String): List<Canal> =
        if (nombre == "Todos los canales") canales else canales.filter { it.grupo == nombre }

    /** Fuerza una nueva descarga la proxima vez (tras cambiar ajustes). */
    fun invalidar() {
        canales = emptyList()
        ultimoTexto = null
    }

    fun olvidar(ctx: Context) {
        prefs(ctx).edit().clear().apply()
        invalidar()
    }

    private fun direcciones(ctx: Context): List<String> {
        val p = prefs(ctx)
        val usuario = p.getString("usuario", "").orEmpty()
        val clave = p.getString("clave", "").orEmpty()
        return listOf(p.getString("url", "").orEmpty(), p.getString("url2", "").orEmpty())
            .map { M3u.direccionLista(it, usuario, clave) }
            .filter { it.isNotEmpty() }
    }

    /** Descarga la lista. alTerminar(ok, mensaje, hayCambios) se llama en el hilo principal. */
    fun cargar(ctx: Context, alTerminar: (Boolean, String, Boolean) -> Unit) {
        val dirs = direcciones(ctx)
        if (dirs.isEmpty()) {
            alTerminar(false, "Falta la direccion del servidor", false)
            return
        }
        hilo.execute {
            var texto: String? = null
            var fallo = ""
            for (d in dirs) {
                try {
                    texto = M3u.descargar(d, if (dirs.size > 1) 4000 else 15000)
                    break
                } catch (e: Exception) {
                    fallo = e.message ?: e.javaClass.simpleName
                }
            }
            val resultado = texto
            principal.post {
                if (resultado == null) {
                    alTerminar(false, fallo, false)
                } else {
                    val cambio = resultado != ultimoTexto
                    if (cambio) {
                        ultimoTexto = resultado
                        canales = M3u.parsear(resultado)
                    }
                    alTerminar(true, "", cambio)
                }
            }
        }
    }
}
