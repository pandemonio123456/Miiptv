package com.iptv.mio

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private var primera = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        primera = intent.getBooleanExtra("primera", false) || !Repo.configurado(this)
        val p = Repo.prefs(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(60), dp(40), dp(60), dp(40))
        }
        val scroll = ScrollView(this)
        scroll.addView(col)

        fun add(v: View) {
            col.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun texto(t: String, tam: Float = 16f, color: Int = Color.LTGRAY): TextView =
            TextView(this).apply {
                text = t
                textSize = tam
                setTextColor(color)
                setPadding(0, dp(12), 0, dp(4))
            }

        fun campo(pista: String, valor: String, numero: Boolean = false, secreto: Boolean = false): EditText =
            EditText(this).apply {
                hint = pista
                setText(valor)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                setSingleLine(true)
                if (numero) {
                    inputType = InputType.TYPE_CLASS_NUMBER
                } else if (secreto) {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                }
            }

        fun boton(t: String, accion: () -> Unit): Button =
            Button(this).apply {
                text = t
                setOnClickListener { accion() }
            }

        add(texto(if (primera) "Primera configuración" else "Ajustes", 26f, Color.WHITE))
        add(texto("Dirección del servidor (IP de casa)"))
        val casa = campo("http://192.168.1.50:9191", p.getString("url", "").orEmpty())
        add(casa)
        add(texto("Usuario de Dispatcharr"))
        val usuario = campo("Usuario", p.getString("usuario", "").orEmpty())
        add(usuario)
        add(texto("Contraseña (XC password de Dispatcharr)"))
        val clave = campo("Contraseña", p.getString("clave", "").orEmpty(), secreto = true)
        add(clave)

        val fuera = campo("http://100.x.x.x:9191", p.getString("url2", "").orEmpty())
        val nombre = campo("MINIPTV", p.getString("nombre", "").orEmpty())
        val ocultar = campo("2", p.getInt("ocultar", 2).toString(), numero = true)
        val intervalo = campo("60", p.getInt("intervalo", 60).toString(), numero = true)
        val auto = Switch(this).apply {
            text = "Recargar la lista sola"
            setTextColor(Color.WHITE)
            isChecked = p.getBoolean("auto", true)
        }

        if (!primera) {
            add(texto("Dirección fuera de casa (Tailscale)"))
            add(fuera)
            add(texto("Nombre de la lista (sale en la pantalla principal)"))
            add(nombre)
            add(texto("Segundos hasta ocultar los controles del vídeo"))
            add(ocultar)
            add(texto("Comprobar cambios en la lista cada (segundos)"))
            add(intervalo)
            add(auto)
        }

        add(boton("Guardar") {
            val ed = p.edit()
                .putString("url", casa.text.toString().trim())
                .putString("usuario", usuario.text.toString().trim())
                .putString("clave", clave.text.toString())
            if (!primera) {
                ed.putString("url2", fuera.text.toString().trim())
                    .putString("nombre", nombre.text.toString().trim())
                    .putInt("ocultar", ocultar.text.toString().toIntOrNull() ?: 2)
                    .putInt("intervalo", intervalo.text.toString().toIntOrNull() ?: 60)
                    .putBoolean("auto", auto.isChecked)
            }
            ed.apply()
            Repo.invalidar()
            finish()
        })

        if (!primera) {
            add(boton("Recargar lista ahora") {
                Repo.cargar(this) { ok, msg, _ ->
                    if (!isDestroyed) {
                        if (ok) aviso("Lista cargada: ${Repo.canales.size} canales") else aviso("Error: $msg")
                    }
                }
            })
            add(boton("Borrar configuración (salir de la cuenta)") {
                Repo.olvidar(this)
                finish()
            })
            add(texto("MINIPTV · versión " + versionApp(this) + " · solo reproduce tu lista de Dispatcharr", 14f))
        }

        setContentView(scroll)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (primera) finishAffinity() else super.onBackPressed()
    }
}
