package com.iptv.mio

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class LiveActivity : AppCompatActivity() {

    private enum class Modo { GRUPOS, CANALES }

    private val manejador = Handler(Looper.getMainLooper())
    private var reproductor: ExoPlayer? = null

    private lateinit var visor: PlayerView
    private lateinit var tapa: View
    private lateinit var etiqueta: TextView
    private lateinit var panel: View
    private lateinit var oscuro: View
    private lateinit var cabecera: TextView
    private lateinit var lista: RecyclerView

    private var enGrande = false
    private var modo = Modo.GRUPOS
    private var grupoElegido = "Todos los canales"
    private var canalActual: Canal? = null
    private var miniAncho = 0
    private var miniAlto = 0
    private var margen = 0

    private val reintento = Runnable { canalActual?.let { reproducir(it) } }

    private val vigilante = object : Runnable {
        override fun run() {
            if (Repo.autoRecarga(this@LiveActivity)) cargar(true)
            manejador.postDelayed(this, Repo.intervalo(this@LiveActivity) * 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ancho = resources.displayMetrics.widthPixels
        margen = dp(24)
        miniAncho = (ancho * 0.42f).toInt()
        miniAlto = miniAncho * 9 / 16

        val raiz = FrameLayout(this)

        raiz.addView(
            ImageView(this).apply {
                setImageDrawable(fondoDrawable(this@LiveActivity))
                scaleType = ImageView.ScaleType.CENTER_CROP
            },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        oscuro = View(this).apply { setBackgroundColor(Color.argb(150, 0, 0, 0)) }
        raiz.addView(oscuro, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        cabecera = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(20), dp(20), dp(12))
            setOnClickListener { if (modo == Modo.CANALES) mostrarGrupos() }
        }
        lista = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@LiveActivity)
        }
        val columnaIzq = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(210, 12, 12, 12))
            addView(cabecera, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(lista, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        panel = columnaIzq
        raiz.addView(panel, FrameLayout.LayoutParams((ancho * 0.36f).toInt(), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START))

        visor = PlayerView(this).apply { setUseController(false) }
        raiz.addView(visor, posicionMini(miniAlto))

        tapa = View(this).apply {
            isFocusable = true
            isClickable = true
            setOnClickListener { entrarGrande() }
        }
        raiz.addView(tapa, posicionMini(miniAlto))

        etiqueta = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        raiz.addView(etiqueta, FrameLayout.LayoutParams(miniAncho, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))

        setContentView(raiz)
        aplicarMini()
    }

    private fun posicionMini(alto: Int) = FrameLayout.LayoutParams(miniAncho, alto, Gravity.TOP or Gravity.END).apply {
        topMargin = margen
        rightMargin = margen
    }

    private fun aplicarMini() {
        enGrande = false
        visor.setUseController(false)
        visor.layoutParams = posicionMini(miniAlto)
        tapa.layoutParams = posicionMini(miniAlto)
        tapa.visibility = View.VISIBLE
        etiqueta.layoutParams = FrameLayout.LayoutParams(miniAncho, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            topMargin = margen + miniAlto + dp(8)
            rightMargin = margen
        }
        etiqueta.visibility = View.VISIBLE
        panel.visibility = View.VISIBLE
        oscuro.visibility = View.VISIBLE
    }

    private fun entrarGrande() {
        enGrande = true
        visor.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        visor.setUseController(true)
        visor.setControllerShowTimeoutMs(Repo.segundosOcultar(this) * 1000)
        visor.showController()
        tapa.visibility = View.GONE
        etiqueta.visibility = View.GONE
        panel.visibility = View.GONE
        oscuro.visibility = View.GONE
    }

    private fun salirGrande() {
        aplicarMini()
        tapa.requestFocus()
    }

    override fun onStart() {
        super.onStart()
        val p = ExoPlayer.Builder(this).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                manejador.postDelayed(reintento, 3000)
            }
        })
        visor.player = p
        reproductor = p
        canalActual?.let { reproducir(it) }
    }

    override fun onResume() {
        super.onResume()
        if (Repo.canales.isEmpty()) {
            cargar(false)
        } else if (modo == Modo.GRUPOS) {
            mostrarGrupos()
        }
        if (canalActual == null && Repo.canales.isNotEmpty()) elegirInicial()
        manejador.removeCallbacks(vigilante)
        manejador.postDelayed(vigilante, Repo.intervalo(this) * 1000L)
    }

    override fun onPause() {
        super.onPause()
        manejador.removeCallbacks(vigilante)
    }

    override fun onStop() {
        super.onStop()
        manejador.removeCallbacksAndMessages(null)
        visor.player = null
        reproductor?.release()
        reproductor = null
    }

    private fun cargar(silencioso: Boolean) {
        Repo.cargar(this) { ok, mensaje, cambio ->
            if (!isDestroyed) resultadoCarga(ok, mensaje, cambio, silencioso)
        }
    }

    private fun resultadoCarga(ok: Boolean, mensaje: String, cambio: Boolean, silencioso: Boolean) {
        if (!ok) {
            if (!silencioso) aviso("No se pudo cargar la lista: $mensaje")
            return
        }
        if (cambio) {
            if (silencioso) aviso("Lista actualizada: ${Repo.canales.size} canales")
            if (modo == Modo.CANALES) mostrarCanales(grupoElegido, Repo.delGrupo(grupoElegido)) else mostrarGrupos()
        } else if (!silencioso) {
            aviso("La lista no ha cambiado")
        }
        if (canalActual == null) elegirInicial()
    }

    private fun elegirInicial() {
        val nombre = Repo.ultimo(this)
        val c = Repo.canales.firstOrNull { it.nombre == nombre } ?: Repo.canales.firstOrNull() ?: return
        reproducir(c)
    }

    private fun reproducir(c: Canal) {
        canalActual = c
        Repo.guardarUltimo(this, c.nombre)
        etiqueta.text = c.nombre
        manejador.removeCallbacks(reintento)
        val p = reproductor ?: return
        p.setMediaItem(MediaItem.fromUri(c.url))
        p.prepare()
        p.playWhenReady = true
    }

    private fun cambiarCanal(paso: Int) {
        val contexto = Repo.delGrupo(grupoElegido)
        val actual = canalActual ?: return
        if (contexto.isEmpty()) return
        val indice = contexto.indexOfFirst { it.url == actual.url }
        if (indice < 0) return
        reproducir(contexto[(indice + paso + contexto.size) % contexto.size])
    }

    private fun mostrarGrupos() {
        modo = Modo.GRUPOS
        cabecera.text = Repo.nombreLista(this) + "  ·  " + Repo.canales.size + " canales"
        val grupos = Repo.canales.map { it.grupo }.distinct()
        val filas = listOf("Todos los canales") + grupos
        lista.adapter = Adaptador(filas) { i ->
            val nombre = filas[i]
            mostrarCanales(nombre, Repo.delGrupo(nombre))
        }
        lista.requestFocus()
    }

    private fun mostrarCanales(nombre: String, del: List<Canal>) {
        modo = Modo.CANALES
        grupoElegido = nombre
        cabecera.text = "←  " + nombre
        val filas = mutableListOf("←  Volver a grupos")
        for (c in del) {
            filas.add((if (c.url == canalActual?.url) "▶  " else "") + c.nombre)
        }
        lista.adapter = Adaptador(filas) { i ->
            if (i == 0) {
                mostrarGrupos()
            } else {
                reproducir(del[i - 1])
                mostrarCanales(nombre, del)
            }
        }
        lista.requestFocus()
    }

    override fun dispatchKeyEvent(evento: KeyEvent): Boolean {
        if (evento.action == KeyEvent.ACTION_DOWN && enGrande && !visor.isControllerFullyVisible) {
            when (evento.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                    cambiarCanal(1)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                    cambiarCanal(-1)
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(evento)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            enGrande -> salirGrande()
            modo == Modo.CANALES -> mostrarGrupos()
            else -> super.onBackPressed()
        }
    }
}
